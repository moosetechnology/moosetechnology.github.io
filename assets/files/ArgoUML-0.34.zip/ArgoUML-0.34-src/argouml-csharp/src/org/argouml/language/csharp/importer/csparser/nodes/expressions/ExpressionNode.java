package org.argouml.language.csharp.importer.csparser.nodes.expressions;

/**
 * Created by IntelliJ IDEA.
 * User: Thilina
 * Date: Jun 7, 2008
 * Time: 12:19:22 PM
 * To change this template use File | Settings | File Templates.
 */
public abstract class ExpressionNode extends BaseNode {
}