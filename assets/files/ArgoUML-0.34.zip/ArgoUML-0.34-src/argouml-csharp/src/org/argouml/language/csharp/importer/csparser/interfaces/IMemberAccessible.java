package org.argouml.language.csharp.importer.csparser.interfaces;

/**
 * Created by IntelliJ IDEA.
 * User: Thilina
 * Date: Jun 7, 2008
 * Time: 1:52:10 PM
 * To change this template use File | Settings | File Templates.
 */
public interface IMemberAccessible extends ISourceCode
	{
	}
