package org.argouml.language.csharp.importer.csparser.preprocessornodes;

import org.argouml.language.csharp.importer.csparser.nodes.expressions.ExpressionNode;

/**
 * Created by IntelliJ IDEA.
 * User: Administrator
 * Date: Jun 18, 2008
 * Time: 11:39:45 AM
 */
public class PPNode extends ExpressionNode {
}