package org.argouml.language.csharp.importer.csparser.statements;

/**
 * Created by IntelliJ IDEA.
 * User: Administrator
 * Date: Jun 18, 2008
 * Time: 1:11:07 PM
 */
public class UncheckedStatement extends StatementNode
	{
		public BlockStatement UncheckedBlock;

        public void ToSource(StringBuilder sb)
        {

        }
	}