package org.argouml.language.csharp.importer.csparser.enums;

/**
 * Created by IntelliJ IDEA.
 * User: Thilina
 * Date: Jun 7, 2008
 * Time: 12:40:30 PM
 * To change this template use File | Settings | File Templates.
 */
public enum IntegralType
	{
		SByte,
		Byte,
		Short,
		UShort,
		Int,
		UInt,
		Long,
		ULong,
		Char,
	}