package org.argouml.language.csharp.importer.csparser.nodes.expressions.primitive;

import org.argouml.language.csharp.importer.csparser.nodes.expressions.PrimaryExpression;

/**
 * Created by IntelliJ IDEA.
 * User: Thilina
 * Date: Jun 7, 2008
 * Time: 6:03:08 PM
 */
public abstract class LiteralNode extends PrimaryExpression {
}
