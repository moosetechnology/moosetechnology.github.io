package org.argouml.language.csharp.importer.csparser.preprocessornodes;

/**
 * Created by IntelliJ IDEA.
 * User: Administrator
 * Date: Jun 18, 2008
 * Time: 11:40:40 AM
 */
public class PPEndIfNode extends PPNode {
    public PPEndIfNode() {
    }
}
