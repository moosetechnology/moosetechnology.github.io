package org.argouml.language.csharp.importer.csparser.main;

/**
 * @author Thilina Hasantha
 * @date: Aug 7, 2008
 * @time: 9:06:50 AM
 */
public class FeatureNotSupportedException  extends Exception{
    public FeatureNotSupportedException(String message) {
        super(message);
    }
}
