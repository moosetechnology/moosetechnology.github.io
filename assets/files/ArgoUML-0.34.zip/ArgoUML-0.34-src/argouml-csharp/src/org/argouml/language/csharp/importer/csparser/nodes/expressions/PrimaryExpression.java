package org.argouml.language.csharp.importer.csparser.nodes.expressions;

import org.argouml.language.csharp.importer.csparser.interfaces.IMemberAccessible;

/**
 * Created by IntelliJ IDEA.
 * User: Thilina
 * Date: Jun 7, 2008
 * Time: 6:18:52 PM
 */
public class PrimaryExpression extends ExpressionNode implements IMemberAccessible {
}
