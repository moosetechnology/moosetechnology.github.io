package org.argouml.language.csharp.importer.csparser.statements;

/**
 * Created by IntelliJ IDEA.
 * User: Administrator
 * Date: Jun 18, 2008
 * Time: 11:48:12 AM
 */
public class ContinueStatement extends StatementNode {
    private String Target;

    public void ToSource(StringBuilder sb) {

    }
}
