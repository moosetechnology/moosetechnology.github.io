# This is where your source code goes.

The source code for this project is just the property files needed
to run argouml in Chinese.
